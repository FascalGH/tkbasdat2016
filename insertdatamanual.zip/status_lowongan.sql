INSERT INTO status_lamaran VALUES
(1, 'melamar'),
(2, 'direkomendasi'),
(3, 'diterima'),
(4, 'ditolak');