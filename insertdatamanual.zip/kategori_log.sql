INSERT INTO kategori_log VALUES
(1, 'asistensi/tutorial'),
(2, 'persiapan asistensi'),
(3, 'membuat soal/tugas'),
(4, 'rapat'),
(5, 'sit in kelas'),
(6, 'mengoreksi'),
(7, 'mengawas');