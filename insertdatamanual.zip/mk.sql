INSERT INTO mata_kuliah VALUES
('M0001', 'Metode Sampling', NULL),
('M0002', 'Statistik Matematika', 'M0005'),
('M0003', 'Aljabar Linier', NULL),
('M0004', 'Kalkulus', 'M0003'),
('M0005', 'Matematika Dasar', NULL),
('M0006', 'Fisika Dasar', NULL),
('M0007', 'Agama', NULL),
('M0008', 'Matematika Diskrit', NULL),
('M0009', 'Kalkulus 2', 'M0004'),
('M0010', 'Matematika Dasar 2', 'M0005');